package edu.aspire.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import edu.aspire.domain.Student;

public class StudentDaoImpl {
		private static SessionFactory  factory = null;
		static{
			Configuration cfg = new Configuration();//Starts hibernate framework
			cfg.configure("hibernate.cfg.xml");//Loads hibernate configuration file into hibernate framework.
			factory = cfg.buildSessionFactory();//Builds sf object. Also, creates & manages pool of connections
		}

		//INSERT operation
		public void create(Student s1){
			Session s = factory.openSession(); //Open session
			Transaction tx = s.beginTransaction();//begins tx
			s.save(s1);
			s.flush();
			tx.commit();
			s.close();
		}
}
