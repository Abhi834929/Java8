package edu.aspire.test;
import edu.aspire.domain.Student;
import edu.aspire.dao.StudentDaoImpl;

import org.junit.Assert;
import org.junit.Test;

public class StudentDaoTest{
	@Test
	public void testCreate(){
		StudentDaoImpl dao = new StudentDaoImpl();
		Student s = new Student();
		s.setSno(1);
		s.setSname("abc");
		s.setEmail("abc@java2aspire.com");
		s.setMobile(7799108899L);
		dao.create(s);
		Assert.assertEquals(true, true);
	}
}
