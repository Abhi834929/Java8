package edu.aspire.test;
import junit.framework.Assert;
import org.junit.Test;
import edu.aspire.jdbc.DatabaseMetadataEx;

public class DatabaseMetadataTest{
	@Test
	public void testDbdetails(){
		DatabaseMetadataEx obj = new DatabaseMetadataEx();
		obj.dbdetails();
		Assert.assertEquals(true, true);
	}
}
