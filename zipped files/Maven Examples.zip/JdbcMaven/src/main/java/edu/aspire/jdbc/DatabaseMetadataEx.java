package edu.aspire.jdbc;
import java.sql.*;
public class DatabaseMetadataEx{
	public void dbdetails(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
			DatabaseMetaData db = con.getMetaData();
			System.out.println("******************************************");
			System.out.println("Database name : " + db.getDatabaseProductName());
			System.out.println("Database Product version : " + db.getDatabaseProductVersion());
			System.out.println("\nDriver Name : " + db.getDriverName());
			System.out.println("Driver Version : " + db.getDriverVersion());
			System.out.println("******************************************");
			con.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}